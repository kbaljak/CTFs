import random
import string
ADMIN_USERNAME = "admin"
PW = random.choices(string.digits, k=32)
