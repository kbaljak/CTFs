#include <stdio.h> 
#include <string.h>

void shouter() {
    char buf[32];
    memset(buf, 0, 32);
    printf("What do you want to shout!\n> ");
    fgets(buf, 128, stdin);

    char c;
    int i = 0;
    while ((c = buf[i]) != '\x00') {
        if (c >= 'a' && c <= 'z') {
            printf("%c", c - ('a' - 'A'));
        } else {
            printf("%c", c);
        }
        i++;
    }
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    while (1)
        shouter();

    return 0;
}
