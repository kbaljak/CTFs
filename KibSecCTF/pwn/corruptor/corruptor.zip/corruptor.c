#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

void func() {
    volatile int magic = 0x13371337;
    volatile char buf[32];
    memset(buf, 0, 32);
    printf("Are you a corruptor?\n> ");
    read(STDIN_FILENO, buf, 128);
    
    if (strcmp(buf, "yes") == 0 && magic == 0xdeadbeef)  {
        FILE* file = fopen("flag.txt", "r");
        char flag[64];
        fgets(flag, 64, file);
        puts(flag);
        exit(0);
    }
    puts("Seems like you aren't much of a corruptor");
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    func();
    return 0;
}
