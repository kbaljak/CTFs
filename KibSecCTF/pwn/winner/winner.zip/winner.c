#include <stdio.h> 
#include <string.h>

void win() {
    FILE* file = fopen("flag.txt", "r");
    char flag[64];
    fgets(flag, 64, file);
    puts(flag);
}

void func() {
    char buf[32];
    memset(buf, 0, 32);
    printf("Are you a winner?\n> ");
    fgets(buf, 32, stdin);

    if (strcmp(buf, "yes\n") == 0) {
        printf("Prove it\n> ");
        fgets(buf, 128, stdin);
    } else {
        puts("Every winner would answer yes :(");
    }
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    func();

    puts("Seems like you aren't much of a winner.");

    return 0;
}
